const body = document.querySelector('body');

//modal-window
const modal = document.querySelector('.modal');
const openModal = document.querySelector('.open-modal');
const modalOverlay = document.querySelector('.modal__overlay');

openModal.addEventListener('click', function () {
    modal.classList.remove('hidden');
    modalOverlay.classList.remove('hidden');
    body.classList.add('no-scroll');
})

modalOverlay.addEventListener('click', function () {
    modal.classList.add('hidden');
    modalOverlay.classList.add('hidden');
    body.classList.remove('no-scroll');
})


//slider-swiper
const swiper = new Swiper('.swiper', {
    loop: true,
    slidesPerView: 4,
    spaceBetween: 15,

    pagination: {
        el: ".swiper-pagination",
        type: "progressbar",
    },

});